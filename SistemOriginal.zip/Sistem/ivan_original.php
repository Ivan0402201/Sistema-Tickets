<?php
require 'bd.php'; // Conexión a la base de datos

$idadmi = 6;  // ID del administrador actual

// Definir cuántos tickets mostrar por página
$tickets_por_pagina = 8;

// Obtener el número total de tickets según el filtro de status
$status_filter = isset($_GET['status']) ? $_GET['status'] : ''; // Obtener filtro de status
$cerrados_por_admi = isset($_GET['cerrados_por_admi']) ? $_GET['cerrados_por_admi'] : ''; // Filtro para los tickets cerrados por el admin actual

$query_total_tickets = "SELECT COUNT(*) FROM tickets";
$conditions = [];

// Condiciones de filtro
if ($status_filter) {
    $conditions[] = "status = :status";
}
if ($cerrados_por_admi) {
    $conditions[] = "cerrado_por = :cerrado_por_admi";
}

if (count($conditions) > 0) {
    $query_total_tickets .= " WHERE " . implode(" AND ", $conditions);
}

$stmt_total_tickets = $pdo->prepare($query_total_tickets);

if ($status_filter) {
    $stmt_total_tickets->bindValue(':status', $status_filter, PDO::PARAM_STR);
}

if ($cerrados_por_admi) {
    $stmt_total_tickets->bindValue(':cerrado_por_admi', $idadmi, PDO::PARAM_INT);
}

$stmt_total_tickets->execute();
$total_tickets = $stmt_total_tickets->fetchColumn();

// Calcular el número total de páginas
$total_paginas = ceil($total_tickets / $tickets_por_pagina);

// Obtener el número de página actual desde la URL, o establecerlo a 1
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$pagina_actual = max($pagina_actual, 1); // Asegurarse de que la página sea al menos 1
$pagina_actual = min($pagina_actual, $total_paginas); // Asegurarse de que no exceda el total de páginas

// Calcular el índice de inicio para la consulta
$inicio = ($pagina_actual - 1) * $tickets_por_pagina;

// Manejar la búsqueda de tickets con paginación y filtro de status
$search_query = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $search_query = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_STRING);
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario, ad.nombreAdmi 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        LEFT JOIN admis ad ON t.cerrado_por = ad.idAdmi
        WHERE (t.id_ticket LIKE :search 
        OR u.nombre LIKE :search 
        OR a.nombreArea LIKE :search)
        " . ($status_filter ? " AND t.status = :status" : "") . "
        " . ($cerrados_por_admi ? " AND t.cerrado_por = :cerrado_por_admi" : "") . "
        ORDER BY t.fecha DESC
        LIMIT :inicio, :tickets_por_pagina
    ");
    $stmt->bindValue('search', '%' . $search_query . '%', PDO::PARAM_STR);
} else {
    // Obtener tickets con paginación y filtro de status si no hay búsqueda
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario, ad.nombreAdmi 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        LEFT JOIN admis ad ON t.cerrado_por = ad.idAdmi
        " . ($status_filter ? " WHERE t.status = :status" : "") . "
        " . ($cerrados_por_admi ? " WHERE t.cerrado_por = :cerrado_por_admi" : "") . "
        ORDER BY t.fecha DESC
        LIMIT :inicio, :tickets_por_pagina
    ");
}

if ($status_filter) {
    $stmt->bindValue('status', $status_filter, PDO::PARAM_STR);
}

if ($cerrados_por_admi) {
    $stmt->bindValue('cerrado_por_admi', $idadmi, PDO::PARAM_INT);
}

$stmt->bindValue('inicio', $inicio, PDO::PARAM_INT);
$stmt->bindValue('tickets_por_pagina', $tickets_por_pagina, PDO::PARAM_INT);
$stmt->execute();
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Manejar la solicitud de cierre de ticket
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_ticket']) && isset($_POST['trabajorealizado'])) {
    $id_ticket = filter_input(INPUT_POST, 'id_ticket', FILTER_SANITIZE_NUMBER_INT);
    $trabajorealizado = $_POST['trabajorealizado'];
    try {
        $stmt = $pdo->prepare("
        UPDATE tickets
        SET status = 'cerrado',
        fechaCerrado = NOW(),
        cerrado_por = :idadmi,
        trabajorealizado = '$trabajorealizado'
        WHERE id_ticket = :id_ticket");
        $stmt->execute([
            'id_ticket' => $id_ticket,
            'idadmi' => $idadmi
        ]);

        //Se agrego idAdmi y fecha lectura registraría el administrador responsable y marcaría el momento en que fue cerrada.

        $stmt = $pdo->prepare("
        UPDATE notificaciones
        SET tipo = 'Cerrado',
        idAdmi = :idadmi, 
        fecha_lectura = NOW()
        WHERE id_ticket = :id_ticket");
        $stmt->execute([
            'id_ticket' => $id_ticket,
            'idadmi' => $idadmi
        ]);


        header('Location: ivan_original.php');
        exit();
    } catch (PDOException $e) {
        echo "Error al cerrar el ticket: " . $e->getMessage();
    }




}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ivan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-red {
            background-color: red;
            color: white;
        }
        .status-open {
            background-color: green;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">IVAN</h1>

    <!-- Formulario de Búsqueda -->
    <form method="POST" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Buscar por ID, Usuario o Área" value="<?php echo htmlspecialchars($search_query); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>

    <!-- Filtro de Status -->
    <div class="mb-4">
        <label for="filterStatus" class="form-label">Filtrar por estado:</label>
        <select id="filterStatus" class="form-select" onchange="location = this.value;">
            <option value="ivan_original.php" <?php if ($status_filter == '') echo 'selected'; ?>>Todos</option>
            <option value="ivan_original.php?status=abierto" <?php if ($status_filter == 'abierto') echo 'selected'; ?>>Abierto</option>
            <option value="ivan_original.php?status=cerrado" <?php if ($status_filter == 'cerrado') echo 'selected'; ?>>Cerrado</option>
        </select>
    </div>


<!-- Filtro de Cerrados por Administrador -->
<div class="mb-4">
    <label for="filterAdmin" class="form-label">Filtrar por tickets cerrados por el administrador:</label>
    <select id="filterAdmin" class="form-select" onchange="location = this.value;">
        <option value="ivan_original.php" <?php if ($cerrados_por_admi == '') echo 'selected'; ?>>Todos</option>
        <option value="ivan_original.php?cerrados_por_admi=1" <?php if ($cerrados_por_admi == '1') echo 'selected'; ?>>Cerrados por mí</option>
    </select>
</div>

    <a href="exportar_pdf.php" class="btn btn-success" target="_blank">Exportar a PDF</a>

    <!-- Tabla de Tickets -->
    <table class="table table-striped">
        <thead>
        <tr>
            <th>ID Ticket</th>
            <th>Nombre Usuario</th>
            <th>Área Generadora</th>
            <th>Fecha</th>
            <th>Falla</th>
            <th>Observaciones</th>
            <th>Status</th>
            <th>Fecha de Cierre</th>
            <th>Cerrado Por</th>
            <th>Resultado</th>
            <th>Modificar</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $ticket): ?>
            <tr>
                <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombreArea']); ?></td>
                <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <span class="status-open">Abierto</span>
                    <?php else: ?>
                        <?php echo htmlspecialchars($ticket['status']); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'cerrado'): ?>
                        <?php echo htmlspecialchars($ticket['fechaCerrado']); ?>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'cerrado'): ?>
                        <?php echo htmlspecialchars($ticket['nombreAdmi']); ?>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td>
                <?php echo htmlspecialchars($ticket['trabajorealizado']) ?: 'N/A'; ?> <!-- Nueva celda -->
            </td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modificarModal<?php echo $ticket['id_ticket']; ?>">Modificar</button>
                    <?php endif; ?>
                </td>
            </tr>

            <!-- Modal para cerrar el ticket -->
            <div class="modal fade" id="modificarModal<?php echo $ticket['id_ticket']; ?>" tabindex="-1" aria-labelledby="modificarModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modificarModalLabel">Cerrar Ticket ID: <?php echo $ticket['id_ticket']; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <p>¿Está seguro de cerrar este ticket?</p>
                                <input type="hidden" name="id_ticket" value="<?php echo $ticket['id_ticket']; ?>">
                                <input type="text" name="trabajorealizado" class="form-control" placeholder="Detalla el trabajo: " value="">
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-danger">Cerrar Ticket</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <nav>
        <ul class="pagination">
            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                    <a class="page-link" href="ivan_original.php?pagina=<?php echo $i; ?>&status=<?php echo htmlspecialchars($status_filter); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>