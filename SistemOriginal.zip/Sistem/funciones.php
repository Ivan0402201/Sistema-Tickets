<?php

/**
 * Summary of obtener_notificaciones
 * @param int $idAdmi
 * @param int $id_area
 * @param string $estado
 * @param string $estadoAdmis
 * @return string JSON con los resultados o mensaje de error
// Ejemplo de uso de la función
    echo obtener_notificaciones(); // Sin parámetros o definir parametros vacios o ceros
    echo obtener_notificaciones(4, 32, 'Pendiente', 'No Leido'); // Con todos los parámetros
 */

function obtener_notificaciones($idAdmi = 0, $id_area = 0, $estado = '', $estadoAdmis = '')
{
    //echo "Esto es idAdmi->$idAdmi<br />";
    //echo "Esto es id_area->$id_area<br />";
    //echo "Esto es estado->$estado<br />";
    //echo "Esto es estadoAdmis->$estadoAdmis<br />";
    //    exit(0);

    try {
        // Configuración de conexión a la base de datos
        $servername = 'localhost';
        $dbname = 'Ivan';
        $username = 'Desarrollo';
        $password = '040201';
        $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Construcción dinámica de las condiciones de consulta
        $condiciones = [];
        $parametros = [];

        if ($idAdmi > 0) {
            $condiciones[] = "notificaciones.idAdmi = :idAdmi";
            $parametros['idAdmi'] = $idAdmi;
        }

        if ($id_area > 0) {
            $condiciones[] = "areas.id_area = :id_area";
            $parametros['id_area'] = $id_area;
        }

        if (!empty($estado)) {
            $condiciones[] = "notificaciones.estado = :estado";
            $parametros['estado'] = $estado;
        }

        if (!empty($estadoAdmis)) {
            $condiciones[] = "(notificaciones.estadoAdmis = :estadoAdmis OR notificaciones.estadoAdmis IS NULL)";
            $parametros['estadoAdmis'] = $estadoAdmis;
        }

        // Si no se envían condiciones, asegura que el query sea válido
        $condicionFinal = count($condiciones) > 0 ? 'WHERE ' . implode(' AND ', $condiciones) : '';

        // Preparar y ejecutar la consulta
        $stmt = $pdo->prepare("
            SELECT 
                ROW_NUMBER() OVER (ORDER BY notificaciones.id DESC) AS registro,
                notificaciones.id,
                notificaciones.id_ticket,
                usuarios.nombre AS usuario,
                areas.id_area,
                areas.nombreArea,
                tickets.falla,
                tickets.fecha AS fecha_ticket,
                tickets.status AS estado
            FROM notificaciones
            JOIN tickets ON notificaciones.id_ticket = tickets.id_ticket
            JOIN areas ON notificaciones.id_area = areas.id_area
            JOIN usuarios ON usuarios.matricula = tickets.matricula
            $condicionFinal
            ORDER BY notificaciones.id Desc
        ");

        $stmt->execute($parametros);
        $notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Retornar resultados como JSON
        return json_encode($notificaciones);
    } catch (PDOException $e) {
        // Manejo de errores y retorno de mensaje
        return json_encode(['error' => 'Error al obtener las notificaciones: ' . $e->getMessage()]);
    }
}

function notificacion_leida($id)
{
    $servername = 'localhost';
    $dbname = 'Ivan';
    $username = 'Desarrollo';
    $password = '040201';
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("
    UPDATE notificaciones
    SET estadoAdmis = 'Leido'
    WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return true;
}
