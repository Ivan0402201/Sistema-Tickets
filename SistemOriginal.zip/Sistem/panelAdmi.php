<?php
require 'bd.php'; // Incluir la conexión a la base de datos

// Manejar la eliminación de un administrador
if (isset($_GET['eliminar'])) {
    $idAdmi = filter_input(INPUT_GET, 'eliminar', FILTER_VALIDATE_INT);

    if ($idAdmi) {
        // Obtener el nombre del administrador para determinar el archivo a eliminar
        $stmt = $pdo->prepare("SELECT NombreAdmi FROM admis WHERE idAdmi = :idAdmi");
        $stmt->execute(['idAdmi' => $idAdmi]);
        $admi = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admi) {
            // Eliminar el registro del administrador
            $stmt = $pdo->prepare("DELETE FROM admis WHERE idAdmi = :idAdmi");
            $stmt->execute(['idAdmi' => $idAdmi]);

            // Crear el nombre del archivo a eliminar
            $fileName = strtolower(str_replace(' ', '_', $admi['NombreAdmi'])); // Convertir a minúsculas y reemplazar espacios
            $filePath = "{$fileName}.php"; // Nombre del archivo

            // Eliminar el archivo, si existe
            if (file_exists($filePath)) {
                unlink($filePath); // Eliminar el archivo
            }

            header("Location: panelAdmi.php"); // Redirige después de eliminar
            exit();
        }
    }
}

// Manejar el registro de un nuevo administrador
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreAdmi = filter_input(INPUT_POST, 'NombreAdmi', FILTER_SANITIZE_STRING);
    $correoAdmi = filter_input(INPUT_POST, 'CorreoAdmi', FILTER_SANITIZE_EMAIL);
    $clave = $_POST['clave']; // Guardar la contraseña tal cual se ingresa

    if ($nombreAdmi && $correoAdmi && $clave) {
        // Insertar el administrador en la base de datos
        $stmt = $pdo->prepare("INSERT INTO admis (NombreAdmi, CorreoAdmi, clave) VALUES (:NombreAdmi, :CorreoAdmi, :clave)");
        $stmt->execute(['NombreAdmi' => $nombreAdmi, 'CorreoAdmi' => $correoAdmi, 'clave' => $clave]);

        // Crear un nombre de archivo seguro basado en el nombre del administrador
        $fileName = strtolower(str_replace(' ', '_', $nombreAdmi)); // Convertir a minúsculas y reemplazar espacios
        $filePath = "{$fileName}.php"; // Nombre del archivo

        // Contenido vacío para el archivo admi.php
        $content = <<<EOD
        <?php
        // Este archivo fue generado automáticamente
        ?>

        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Administrador - {$nombreAdmi}</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
        <div class="container mt-5">
            <h1 class="text-center">Página de Administrador - {$nombreAdmi}</h1>
            <p>Esta página está vacía por ahora.</p>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        </body>
        </html>
        EOD;

        // Guardar el archivo
        file_put_contents($filePath, $content);

        header("Location: panelAdmi.php"); // Redirige después de insertar
        exit();
    }
}

// Parámetros de paginación
$registrosPorPagina = 8;
$paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($paginaActual - 1) * $registrosPorPagina;

// Contar el número total de registros
$stmtTotal = $pdo->query("SELECT COUNT(*) FROM admis");
$totalRegistros = $stmtTotal->fetchColumn();
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);

// Obtener administradores con límite y desplazamiento
$stmt = $pdo->prepare("SELECT * FROM admis LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $registrosPorPagina, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$admis = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control de Administradores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function confirmDelete() {
            return confirm("¿Está seguro de que desea eliminar este administrador?");
        }
    </script>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Panel de Control - Registro de Administradores</h1>

    <!-- Botón de salir -->
    <div class="d-flex justify-content-end mb-3">
        <a href="superadmi.php" class="btn btn-danger">Salir</a>
    </div>

    <!-- Formulario para registrar un nuevo administrador -->
    <h2>Registrar Nuevo Administrador</h2>
    <form method="POST" class="mb-4">
        <div class="mb-3">
            <label for="NombreAdmi" class="form-label">Nombre</label>
            <input type="text" id="NombreAdmi" name="NombreAdmi" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="CorreoAdmi" class="form-label">Correo</label>
            <input type="email" id="CorreoAdmi" name="CorreoAdmi" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="clave" class="form-label">Clave</label>
            <input type="text" id="clave" name="clave" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Registrar</button>
    </form>

    <!-- Tabla para mostrar administradores registrados -->
    <h2>Administradores Registrados</h2>
    <table class="table table-striped">
        <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($admis as $admi): ?>
            <tr>
                <td><?php echo $admi['idAdmi']; ?></td>
                <td><?php echo htmlspecialchars($admi['NombreAdmi']); ?></td>
                <td><?php echo htmlspecialchars($admi['CorreoAdmi']); ?></td>
                <td>
                    <a href="?eliminar=<?php echo $admi['idAdmi']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete();">Eliminar</a>
                    <a href="modificarAdmi.php?id=<?php echo $admi['idAdmi']; ?>" class="btn btn-warning btn-sm">Modificar</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Navegación de paginación -->
<nav aria-label="Page navigation">
  <ul class="pagination justify-content-center">
    <!-- Botón de anterior -->
    <li class="page-item <?php if($paginaActual <= 1){ echo 'disabled'; } ?>">
      <a class="page-link" href="?pagina=<?php echo $paginaActual - 1; ?>" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>

    <!-- Generar enlaces de paginación -->
    <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
      <li class="page-item <?php if($paginaActual == $i){ echo 'active'; } ?>">
        <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
      </li>
    <?php endfor; ?>

    <!-- Botón de siguiente -->
    <li class="page-item <?php if($paginaActual >= $totalPaginas){ echo 'disabled'; } ?>">
      <a class="page-link" href="?pagina=<?php echo $paginaActual + 1; ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
</nav>

    </nav>
</div>

<!-- Script de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
