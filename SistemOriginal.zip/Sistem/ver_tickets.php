<?php
require 'bd.php'; // Conexión a la base de datos

// Manejar la búsqueda de tickets
$search_query = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $search_query = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_STRING);
    // Preparar la consulta SQL con búsqueda
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        WHERE t.id_ticket LIKE :search 
        OR u.nombre LIKE :search 
        OR a.nombreArea LIKE :search
    ");
    $stmt->execute(['search' => '%' . $search_query . '%']);
} else {
    // Obtener todos los tickets de todas las áreas si no hay búsqueda
    $stmt = $pdo->query("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
    ");
}
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Manejar la solicitud de cierre de ticket
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_ticket'])) {
    $id_ticket = filter_input(INPUT_POST, 'id_ticket', FILTER_SANITIZE_NUMBER_INT);
    try {
        // Actualizar el estado del ticket a cerrado y establecer la fecha de cierre
        $stmt = $pdo->prepare("UPDATE tickets SET status = 'cerrado', fechacerrado = NOW() WHERE id_ticket = :id_ticket");
        $stmt->execute(['id_ticket' => $id_ticket]);
        
        // Redirigir después de cerrar el ticket
        header('Location: ver_tickets.php');
        exit();
    } catch (PDOException $e) {
        echo "Error al cerrar el ticket: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todos los Tickets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-red {
            background-color: red;
            color: white;
        }
        .status-open {
            background-color: green;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Nombre del Admi</h1>

    <!-- Formulario de Búsqueda -->
    <form method="POST" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Buscar por ID, Usuario o Área" value="<?php echo htmlspecialchars($search_query); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
        <tr>
            <th>ID Ticket</th>
            <th>Nombre Usuario</th>
            <th>Área Generadora</th>
            <th>Fecha</th>
            <th>Falla</th>
            <th>Observaciones</th>
            <th>Status</th>
            <th>Fecha de Cierre</th> <!-- Nueva columna -->
            <th>Modificar</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $ticket): ?>
            <tr>
                <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombreArea']); ?></td>
                <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <span class="status-open">Abierto</span>
                    <?php else: ?>
                        <?php echo htmlspecialchars($ticket['status']); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'cerrado'): ?>
                        <?php echo htmlspecialchars($ticket['fechaCerrado']); ?>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <!-- Botón para abrir el modal de modificación -->
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modificarModal<?php echo $ticket['id_ticket']; ?>">Modificar</button>
                    <?php endif; ?>
                </td>
            </tr>

            <!-- Modal para cerrar el ticket -->
            <div class="modal fade" id="modificarModal<?php echo $ticket['id_ticket']; ?>" tabindex="-1" aria-labelledby="modificarModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modificarModalLabel">Cerrar Ticket ID: <?php echo $ticket['id_ticket']; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <p>¿Estás seguro de que deseas cerrar este ticket?</p>
                                <input type="hidden" name="id_ticket" value="<?php echo htmlspecialchars($ticket['id_ticket']); ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-danger">Cerrar Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="text-center">
        <a href="inicio.html" class="btn btn-red">Salir</a>
    </div>
</div>

<!-- Scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



