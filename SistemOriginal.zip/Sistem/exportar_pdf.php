<?php
require 'bd.php'; // Conexión a la base de datos
require_once('./TCPDF-main/TCPDF-main/tcpdf.php'); // Ruta de TCPDF

// Inicializar variables de filtro
$area = isset($_GET['area']) ? $_GET['area'] : '';
$fechaInicio = isset($_GET['fechaInicio']) ? $_GET['fechaInicio'] : '';
$fechaFin = isset($_GET['fechaFin']) ? $_GET['fechaFin'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$idTicket = isset($_GET['idTicket']) ? $_GET['idTicket'] : '';
$nombreUsuario = isset($_GET['nombreUsuario']) ? $_GET['nombreUsuario'] : '';
$cerradoPor = isset($_GET['cerradoPor']) ? $_GET['cerradoPor'] : '';

// Consulta SQL para obtener todas las áreas
$sqlAreas = "SELECT id_area, nombreArea FROM areas";
$stmtAreas = $pdo->prepare($sqlAreas);
$stmtAreas->execute();
$areas = $stmtAreas->fetchAll(PDO::FETCH_ASSOC);

// Consulta SQL para obtener todos los administradores
$sqlAdmins = "SELECT idAdmi, nombreAdmi FROM admis";
$stmtAdmins = $pdo->prepare($sqlAdmins);
$stmtAdmins->execute();
$administradores = $stmtAdmins->fetchAll(PDO::FETCH_ASSOC);

// Consulta SQL con filtros
$sql = "
    SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario, ad.nombreAdmi AS cerrado_por_admi
    FROM tickets t
    JOIN areas a ON t.id_area = a.id_area
    JOIN usuarios u ON t.matricula = u.matricula
    LEFT JOIN admis ad ON t.cerrado_por = ad.idAdmi
    WHERE 1=1
";

$params = [];
if (!empty($area)) {
    $sql .= " AND a.id_area = :area";
    $params[':area'] = $area;
}
if (!empty($fechaInicio) && !empty($fechaFin)) {
    $sql .= " AND t.fecha BETWEEN :fechaInicio AND :fechaFin";
    $params[':fechaInicio'] = $fechaInicio;
    $params[':fechaFin'] = $fechaFin;
}
if (!empty($status)) {
    $sql .= " AND t.status = :status";
    $params[':status'] = $status;
}
if (!empty($idTicket)) {
    $sql .= " AND t.id_ticket = :idTicket";
    $params[':idTicket'] = $idTicket;
}
if (!empty($nombreUsuario)) {
    $sql .= " AND u.nombre LIKE :nombreUsuario";
    $params[':nombreUsuario'] = "%$nombreUsuario%";
}
if (!empty($cerradoPor)) {
    $sql .= " AND t.cerrado_por = :cerradoPor";
    $params[':cerradoPor'] = $cerradoPor;
}

// Ordenar registros de manera descendente por ID del ticket
$sql .= " ORDER BY t.id_ticket DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Generar PDF
if (isset($_POST['generate_pdf'])) {
    ob_end_clean(); // Limpiar el buffer de salida
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', 'B', 12);
    $html = '<h1>Listado de Tickets</h1>';
    $html .= '<table border="1" cellspacing="0" cellpadding="5">';
    $html .= '<thead>
                <tr>
                    <th>ID Ticket</th>
                    <th>Nombre Usuario</th>
                    <th>Área Generadora</th>
                    <th>Fecha</th>
                    <th>Falla</th>
                    <th>Observaciones</th>
                    <th>Status</th>
                    <th>Fecha de Cierre</th>
                    <th>Cerrado Por</th>
                </tr>
              </thead>
              <tbody>';
    foreach ($tickets as $ticket) {
        $html .= '<tr>
                    <td>' . htmlspecialchars($ticket['id_ticket']) . '</td>
                    <td>' . htmlspecialchars($ticket['nombre_usuario']) . '</td>
                    <td>' . htmlspecialchars($ticket['nombreArea']) . '</td>
                    <td>' . htmlspecialchars($ticket['fecha']) . '</td>
                    <td>' . htmlspecialchars($ticket['falla']) . '</td>
                    <td>' . htmlspecialchars($ticket['observaciones']) . '</td>
                    <td>' . htmlspecialchars($ticket['status']) . '</td>
                    <td>' . htmlspecialchars($ticket['fechaCerrado'] ?? 'N/A') . '</td>
                    <td>' . htmlspecialchars($ticket['cerrado_por_admi'] ?? 'N/A') . '</td>
                  </tr>';
    }
    $html .= '</tbody></table>';
    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('listado_tickets.pdf', 'D');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Tickets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1 class="text-center">Listado de Tickets</h1>
    <form method="get" class="row g-3">
        <div class="col-md-4">
            <input type="text" class="form-control" name="idTicket" placeholder="ID Ticket" value="<?php echo htmlspecialchars($idTicket); ?>">
        </div>
        <div class="col-md-4">
            <input type="text" class="form-control" name="nombreUsuario" placeholder="Nombre Usuario" value="<?php echo htmlspecialchars($nombreUsuario); ?>">
        </div>
        <div class="col-md-4">
            <select class="form-select" name="area">
                <option value="">Selecciona un Área</option>
                <?php foreach ($areas as $areaOption): ?>
                    <option value="<?php echo $areaOption['id_area']; ?>" <?php echo ($area == $areaOption['id_area']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($areaOption['nombreArea']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <input type="date" class="form-control" name="fechaInicio" value="<?php echo htmlspecialchars($fechaInicio); ?>">
        </div>
        <div class="col-md-4">
            <input type="date" class="form-control" name="fechaFin" value="<?php echo htmlspecialchars($fechaFin); ?>">
        </div>
        <div class="col-md-4">
            <select class="form-select" name="status">
                <option value="">Selecciona Status</option>
                <option value="abierto" <?php echo ($status === 'abierto') ? 'selected' : ''; ?>>Abierto</option>
                <option value="cerrado" <?php echo ($status === 'cerrado') ? 'selected' : ''; ?>>Cerrado</option>
            </select>
        </div>
        <div class="col-md-4">
            <select class="form-select" name="cerradoPor">
                <option value="">Cerrado Por</option>
                <?php foreach ($administradores as $admin): ?>
                    <option value="<?php echo $admin['idAdmi']; ?>" <?php echo ($cerradoPor == $admin['idAdmi']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($admin['nombreAdmi']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </div>
    </form>
    <form method="post">
        <button type="submit" name="generate_pdf" class="btn btn-success">Descargar como PDF</button>
    </form>
    <table class="table table-striped table-bordered mt-4">
        <thead>
            <tr>
                <th>ID Ticket</th>
                <th>Nombre Usuario</th>
                <th>Área Generadora</th>
                <th>Fecha</th>
                <th>Falla</th>
                <th>Observaciones</th>
                <th>Status</th>
                <th>Fecha de Cierre</th>
                <th>Cerrado Por</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tickets as $ticket): ?>
                <tr>
                    <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['nombreArea']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['status']); ?></td>
                    <td><?php echo htmlspecialchars($ticket['fechaCerrado'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($ticket['cerrado_por_admi'] ?? 'N/A'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
