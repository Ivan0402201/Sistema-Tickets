<?php
include_once "funciones.php";

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    // Llama a la función que marcará la notificación como leída
    notificacion_leida($id);
    // Devolver una respuesta
    // echo "Notificación marcada como leída con ID: " . $id;
}
