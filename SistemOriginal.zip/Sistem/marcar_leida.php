<?php
require 'bd.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_notificacion'])) {
    $id_notificacion = (int) $_POST['id_notificacion'];
    $stmt = $pdo->prepare("UPDATE notificaciones SET estado = 'Leída', fecha_lectura = NOW() WHERE id = :id");
    $stmt->execute(['id' => $id_notificacion]);

    // Redirigir a la página del administrador
    header('Location: ivan.php');
    exit();
}
?>
