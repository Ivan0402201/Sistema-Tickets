<?php
require 'bd.php'; // Conexión a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['correoAdmi']) && isset($_POST['clave'])) {
    $correoAdmi = $_POST['correoAdmi'];
    $clave = $_POST['clave'];

    // Buscar el administrador con el correo y la clave proporcionados
    $stmt = $pdo->prepare("SELECT NombreAdmi FROM Admis WHERE CorreoAdmi = :correoAdmi AND Clave = :clave");
    $stmt->execute(['correoAdmi' => $correoAdmi, 'clave' => $clave]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // Si encuentra el admin, redirige a su página
    if ($admin) {
        $nombreArchivo = strtolower($admin['NombreAdmi']) . '.php'; // Archivo que tiene el nombre del admin
        header("Location: $nombreArchivo"); // Redirigir a la página del admin
        exit;
    } else {
        $error = "Correo o contraseña incorrectos";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Definir el color azul marino personalizado */
        .bg-navy {
            background-color: #001f3f !important;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

    <!-- Encabezado con color azul marino -->
    <header class="bg-navy text-white py-4">
        <div class="container text-center">
            <h1 class="display-4">Sistema de Tickets</h1>
            <p class="lead">Inicio de Sesión - Admin</p>
        </div>
    </header>

    <!-- Contenido principal -->
    <main class="flex-grow-1 d-flex justify-content-center align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <?php if (isset($error)): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $error; ?>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="correoAdmi" class="form-label">Correo:</label>
                                    <input type="email" id="correoAdmi" name="correoAdmi" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="clave" class="form-label">Contraseña:</label>
                                    <input type="password" id="clave" name="clave" class="form-control" required>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Ingresar</button>
                                </div>
                            </form>
                            <br>
                            <!-- Botón de regresar -->
                            <button class="btn btn-secondary" onclick="window.location.href='inicio.html'">Regresar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Pie de página con color azul marino -->
    <footer class="bg-navy text-white text-center py-3">
        <div class="container">
            <p class="mb-0">&copy; 2024 Sistema de Tickets. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Scripts de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
