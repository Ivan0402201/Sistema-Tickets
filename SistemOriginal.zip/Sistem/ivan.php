<?php
include_once 'bd.php'; // Conexión a la base de datos
include_once 'funciones.php'; // Conexión a la base de datos


//$idadmi = 6;  // ID del administrador actual

/* inicio edison */
$idadmi = 4; //ya definida en linea anterior
$id_area = 0; // obtener desde la base de datos
$estado = ''; // en este momento solo hay Pendientes
$estadoAdmis = 'No leido';
/* fin edison */

// Definir cuántos tickets mostrar por página
$tickets_por_pagina = 8;

// Obtener el número total de tickets según el filtro de status

/* Inicio edison */
$response = obtener_notificaciones($idadmi, $id_area, $estado, $estadoAdmis);
$data = json_decode($response, true); // Decodificar el JSON a un array asociativo
$cantidad_tickets_de_notificaciones = count($data);
/* fin edison */

$status_filter = isset($_GET['status']) ? $_GET['status'] : ''; // Obtener filtro de status
$cerrados_por_admi = isset($_GET['cerrados_por_admi']) ? $_GET['cerrados_por_admi'] : ''; // Filtro para los tickets cerrados por el admin actual

$query_total_tickets = "SELECT COUNT(*) FROM tickets";
$conditions = [];

// Condiciones de filtro
if ($status_filter) {
    $conditions[] = "status = :status";
}
if ($cerrados_por_admi) {
    $conditions[] = "cerrado_por = :cerrado_por_admi";
}

if (count($conditions) > 0) {
    $query_total_tickets .= " WHERE " . implode(" AND ", $conditions);
}

$stmt_total_tickets = $pdo->prepare($query_total_tickets);

if ($status_filter) {
    $stmt_total_tickets->bindValue(':status', $status_filter, PDO::PARAM_STR);
}

if ($cerrados_por_admi) {
    $stmt_total_tickets->bindValue(':cerrado_por_admi', $idadmi, PDO::PARAM_INT);
}

$stmt_total_tickets->execute();
$total_tickets = $stmt_total_tickets->fetchColumn();

// Calcular el número total de páginas
$total_paginas = ceil($total_tickets / $tickets_por_pagina);

// Obtener el número de página actual desde la URL, o establecerlo a 1
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$pagina_actual = max($pagina_actual, 1); // Asegurarse de que la página sea al menos 1
$pagina_actual = min($pagina_actual, $total_paginas); // Asegurarse de que no exceda el total de páginas

// Calcular el índice de inicio para la consulta
$inicio = ($pagina_actual - 1) * $tickets_por_pagina;

// Manejar la búsqueda de tickets con paginación y filtro de status
$search_query = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $search_query = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_STRING);
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario, ad.nombreAdmi 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        LEFT JOIN admis ad ON t.cerrado_por = ad.idAdmi
        WHERE (t.id_ticket LIKE :search 
        OR u.nombre LIKE :search 
        OR a.nombreArea LIKE :search)
        " . ($status_filter ? " AND t.status = :status" : "") . "
        " . ($cerrados_por_admi ? " AND t.cerrado_por = :cerrado_por_admi" : "") . "
        ORDER BY t.fecha DESC
        LIMIT :inicio, :tickets_por_pagina
    ");
    $stmt->bindValue('search', '%' . $search_query . '%', PDO::PARAM_STR);
} else {
    // Obtener tickets con paginación y filtro de status si no hay búsqueda
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario, ad.nombreAdmi 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        LEFT JOIN admis ad ON t.cerrado_por = ad.idAdmi
        " . ($status_filter ? " WHERE t.status = :status" : "") . "
        " . ($cerrados_por_admi ? " WHERE t.cerrado_por = :cerrado_por_admi" : "") . "
        ORDER BY t.fecha DESC
        LIMIT :inicio, :tickets_por_pagina
    ");
}

if ($status_filter) {
    $stmt->bindValue('status', $status_filter, PDO::PARAM_STR);
}

if ($cerrados_por_admi) {
    $stmt->bindValue('cerrado_por_admi', $idadmi, PDO::PARAM_INT);
}

$stmt->bindValue('inicio', $inicio, PDO::PARAM_INT);
$stmt->bindValue('tickets_por_pagina', $tickets_por_pagina, PDO::PARAM_INT);
$stmt->execute();
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Manejar la solicitud de cierre de ticket
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_ticket']) && isset($_POST['trabajorealizado'])) {
    $id_ticket = filter_input(INPUT_POST, 'id_ticket', FILTER_SANITIZE_NUMBER_INT);
    $trabajorealizado = $_POST['trabajorealizado'];
    try {
        $stmt = $pdo->prepare("
        UPDATE tickets
        SET status = 'cerrado',
        fechaCerrado = NOW(),
        cerrado_por = :idadmi,
        trabajorealizado = '$trabajorealizado'
        WHERE id_ticket = :id_ticket");
        $stmt->execute([
            'id_ticket' => $id_ticket,
            'idadmi' => $idadmi
        ]);

        //Se agrego idAdmi y fecha lectura registraría el administrador responsable y marcaría el momento en que fue cerrada.

        $stmt = $pdo->prepare("
        UPDATE notificaciones
        SET tipo = 'Cerrado',
        idAdmi = :idadmi, 
        fecha_lectura = NOW()
        WHERE id_ticket = :id_ticket");
        $stmt->execute([
            'id_ticket' => $id_ticket,
            'idadmi' => $idadmi
        ]);


        header('Location: ivan.php');
        exit();
    } catch (PDOException $e) {
        echo "Error al cerrar el ticket: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Tickets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> <!-- inicio edison -->
    <link rel="stylesheet" href="styles.css">

    <!-- Fin edison -->
</head>

<body>

 <!-- Actualiza la pagina cado 2 minutos -->
<script>
    setInterval(function() {
        location.reload();  // Recarga la página
    }, 120000);  // 120,000 milisegundos = 2 minutos
</script>

    <div class="container mt-5">
        <!-- inicio edison -->
        <div class="py-1">
            <header>
                <h1>Sistema de Tickets</h1>
                <div class="notification-icon" onclick="abrirModal()">
                    <img src="campana.png" alt="Campana de notificaciones" class="notification-icon">
                    <div class="notification-counter" id="notification-counter">
                        <?php echo $cantidad_tickets_de_notificaciones; ?>
                    </div>
                </div>
            </header>
            <main>
                <div class="container mt-5">
                    <!-- fin edison -->
                    <h1 class="text-center">IVAN</h1>

                    <!-- Formulario de Búsqueda -->
                    <form method="POST" class="mb-4">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Buscar por ID, Usuario o Área" value="<?php echo htmlspecialchars($search_query); ?>">
                            <button class="btn btn-primary" type="submit">Buscar</button>
                        </div>
                    </form>

                    <!-- Filtro de Status -->
                    <div class="mb-4">
                        <label for="filterStatus" class="form-label">Filtrar por estado:</label>
                        <select id="filterStatus" class="form-select" onchange="location = this.value;">
                            <option value="ivan.php" <?php if ($status_filter == '') echo 'selected'; ?>>Todos</option>
                            <option value="ivan.php?status=abierto" <?php if ($status_filter == 'abierto') echo 'selected'; ?>>Abierto</option>
                            <option value="ivan.php?status=cerrado" <?php if ($status_filter == 'cerrado') echo 'selected'; ?>>Cerrado</option>
                        </select>
                    </div>

                    <!-- Filtro de Cerrados por Administrador -->
                    <div class="mb-4">
                        <label for="filterAdmin" class="form-label">Filtrar por tickets cerrados por el administrador:</label>
                        <select id="filterAdmin" class="form-select" onchange="location = this.value;">
                            <option value="ivan.php" <?php if ($cerrados_por_admi == '') echo 'selected'; ?>>Todos</option>
                            <option value="ivan.php?cerrados_por_admi=1" <?php if ($cerrados_por_admi == '1') echo 'selected'; ?>>Cerrados por mí</option>
                        </select>
                    </div>

                    <a href="exportar_pdf.php" class="btn btn-success" target="_blank">Exportar a PDF</a>
                </div>
                <!-- inicio edison -->
                <?php
                // Obtener el número total de tickets según el filtro de status
                $response = obtener_notificaciones($idadmi, $id_area, $estado, $estadoAdmis);
                $data = json_decode($response, true); // Decodificar el JSON a un array asociativo
                $cantidad_tickets_de_notificaciones = count($data);
                ?>
                <!-- Fin edison -->
                <!-- Tabla de Tickets -->
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID Ticket</th>
                            <th>Nombre Usuario</th>
                            <th>Área Generadora</th>
                            <th>Fecha</th>
                            <th>Falla</th>
                            <th>Observaciones</th>
                            <th>Status</th>
                            <th>Fecha de Cierre</th>
                            <th>Cerrado Por</th>
                            <th>Resultado</th>
                            <th>Modificar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['nombreArea']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                                <td>
                                    <?php if ($ticket['status'] === 'abierto'): ?>
                                        <span class="status-open">Abierto</span>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($ticket['status']); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($ticket['status'] === 'cerrado'): ?>
                                        <?php echo htmlspecialchars($ticket['fechaCerrado']); ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($ticket['status'] === 'cerrado'): ?>
                                        <?php echo htmlspecialchars($ticket['nombreAdmi']); ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($ticket['trabajorealizado']) ?: 'N/A'; ?> <!-- Nueva celda -->
                                </td>
                                <td>
                                    <?php if ($ticket['status'] === 'abierto'): ?>
                                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modificarModal<?php echo $ticket['id_ticket']; ?>">Modificar</button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Modal para cerrar el ticket -->
                            <div class="modal fade" id="modificarModal<?php echo $ticket['id_ticket']; ?>" tabindex="-1" aria-labelledby="modificarModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="modificarModalLabel">Cerrar Ticket ID: <?php echo $ticket['id_ticket']; ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form method="POST">
                                            <div class="modal-body">
                                                <p>¿Está seguro de cerrar este ticket?</p>
                                                <input type="hidden" name="id_ticket" value="<?php echo $ticket['id_ticket']; ?>">
                                                <input type="text" name="trabajorealizado" class="form-control" placeholder="Detalla el trabajo: " value="">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-danger">Cerrar Ticket</button>
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <!-- inicio edison  -->
            </main>
            <footer>
                <!-- fin edison  -->
                <!-- Paginación -->
                <nav>
                    <ul class="pagination">
                        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                            <li class="page-item <?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                                <a class="page-link" href="ivan.php?pagina=<?php echo $i; ?>&status=<?php echo htmlspecialchars($status_filter); ?>"><?php echo $i; ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
                <!-- inicio edison  -->
                <div id="modal-notificaciones" class="modal">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Notificaciones</h2>
                            <span class="close" onclick="cerrarModal()">&times;</span>
                        </div>
                        <div class="modal-body" id="notificaciones-lista">
                            <!-- Aquí se llenan las notificaciones dinámicamente -->
                            <ul>
                                <?php
                                // Sirve para ordenar un arreglo en un determinado orden
                                // usort($data, function ($a, $b) {
                                //     return $a['id'] <=> $b['id'];
                                // });

                                foreach ($data as $item) {
                                    echo "<li>
                                    <a href='javascript:notificacion_leida(" . $item['id'] . ");' style='margin-bottom:14px;' class='btn'>
                                        <b style='color:red;'>Notificación: </b>{$item['id']},
                                        <b >Ticket:</b>{$item['id_ticket']},
                                        <b>Usuario:</b> {$item['usuario']},
                                        <b>Area:</b> {$item['nombreArea']},
                                        <b>Falla:</b> {$item['falla']},
                                        <b>Fecha:</b> {$item['fecha_ticket']},
                                        <b>Estado:</b> {$item['estado']}
                                        </a>
                                        </li>";
                                }
                                ?>
                            </ul>
                        </div>
                    </div>

            </footer>
            <!-- fin edison  -->
        </div>

        <script>
            // ----------------------------------------------------
            //const API_URL = 'obtener_notificaciones()'; // Ruta del endpoint
            // 
            const data = <?php echo json_encode($data); ?>;

            function notificacion_leida(id) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "notificacion.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        alert('Notificación leída');
                    }
                };
                xhr.send("id=" + id);
                cerrarModal();


            }


            function debounce(fn, delay) {
                let timeout;
                return (...args) => {
                    clearTimeout(timeout);
                    timeout = setTimeout(() => fn(...args), delay);
                };
            }

            async function obtenerNotificaciones() {
                try {
                    const response = await fetch(data);
                    if (!response.ok) throw new Error(`Error ${response.status}: ${response.statusText}`);
                    return await response.json();
                } catch (error) {
                    console.error('Error obteniendo notificaciones:', error.message);
                    return [];
                }
            }

            async function actualizarNotificaciones() {
                const notificaciones = await obtenerNotificaciones();
                const contador = document.getElementById('notification-counter');
                //alert(contador.textContent);

                const lista = document.getElementById('notificaciones-lista');
                console.log("Contador-> ", notification - counter);
                lista.innerHTML = "";

                if (notificaciones.length === 0) {
                    lista.innerHTML = "<ul><li>No hay notificaciones pendientes</li></ul>";
                    return;
                }

                const ul = document.createElement('ul');
                const fragment = document.createDocumentFragment();

                notificaciones.forEach(({
                    mensaje
                }) => {
                    const li = document.createElement('li');
                    li.textContent = mensaje; // Evita XSS
                    fragment.appendChild(li);
                });

                ul.appendChild(fragment);
                lista.appendChild(ul);
            }

            function abrirModal() {
                actualizarNotificaciones();
                document.getElementById('modal-notificaciones').classList.add('visible');
            }

            function cerrarModal() {
                document.getElementById('modal-notificaciones').classList.remove('visible');
                location.reload();
            }

            document.addEventListener('DOMContentLoaded', () => {
                const actualizarNotificacionesDebounced = debounce(actualizarNotificaciones, 300);
                actualizarNotificacionesDebounced();
            });

            // -----------------------------        
        </script>
          
</body>
</html>