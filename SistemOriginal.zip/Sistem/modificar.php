<?php
require 'bd.php'; // Incluir la conexión a la base de datos

// Obtener el id del área que se va a modificar
$id_area = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id_area) {
    die('ID de área no válido');
}

// Obtener el área actual desde la base de datos
$stmt = $pdo->prepare("SELECT * FROM areas WHERE id_area = :id_area");
$stmt->execute(['id_area' => $id_area]);
$area = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$area) {
    die('Área no encontrada');
}

// Manejar la modificación de un área
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nuevoNombreArea = filter_input(INPUT_POST, 'nombreArea', FILTER_SANITIZE_STRING);
    $clave = filter_input(INPUT_POST, 'clave', FILTER_SANITIZE_STRING);

    if ($nuevoNombreArea && $clave) {
        // Nombre de archivo anterior
        $nombreArchivoAnterior = strtolower(str_replace(' ', '_', $area['nombreArea'])) . '.php';
        // Nombre de archivo nuevo
        $nombreArchivoNuevo = strtolower(str_replace(' ', '_', $nuevoNombreArea)) . '.php';

        // Si el nombre ha cambiado, renombrar el archivo
        if ($nuevoNombreArea !== $area['nombreArea']) {
            // Comprobar si el archivo anterior existe
            if (file_exists($nombreArchivoAnterior)) {
                // Obtener el contenido del archivo anterior
                $contenidoAnterior = file_get_contents($nombreArchivoAnterior);

                // Escribir el contenido en el nuevo archivo
                file_put_contents($nombreArchivoNuevo, $contenidoAnterior);

                // Eliminar el archivo anterior
                unlink($nombreArchivoAnterior);
            } else {
                // Si el archivo no existe, crear un nuevo archivo vacío
                $contenidoAnterior = <<<EOD
                <?php
                // Este archivo fue generado automáticamente
                ?>

                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Área - {$nuevoNombreArea}</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                </head>
                <body>
                <div class="container mt-5">
                    <h1 class="text-center">Página de {$nuevoNombreArea}</h1>
                    <p>Esta página está vacía por ahora.</p>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                </body>
                </html>
                EOD;

                file_put_contents($nombreArchivoNuevo, $contenidoAnterior);
            }
        }

        // Actualizar el área en la base de datos
        $stmt = $pdo->prepare("UPDATE areas SET nombreArea = :nombreArea, clave = :clave WHERE id_area = :id_area");
        $stmt->execute(['nombreArea' => $nuevoNombreArea, 'clave' => $clave, 'id_area' => $id_area]);

        // Redirigir al panel
        header("Location: panel.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Área</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Modificar Área</h1>

    <!-- Formulario para modificar el área -->
    <form method="POST">
        <div class="mb-3">
            <label for="nombreArea" class="form-label">Área</label>
            <input type="text" id="nombreArea" name="nombreArea" class="form-control" value="<?php echo htmlspecialchars($area['nombreArea']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="clave" class="form-label">Clave</label>
            <input type="text" id="clave" name="clave" class="form-control" value="<?php echo htmlspecialchars($area['clave']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <a href="panel.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<!-- Script de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
