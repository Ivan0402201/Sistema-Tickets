<?php
require 'bd.php'; // Incluir la conexión a la base de datos

// Manejar la eliminación de un usuario
if (isset($_GET['eliminar'])) {
    $matricula = filter_input(INPUT_GET, 'eliminar', FILTER_SANITIZE_STRING);

    if ($matricula) {
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE matricula = :matricula");
        $stmt->execute(['matricula' => $matricula]);
    }
}

// Manejar el registro de un nuevo usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registrar'])) {
    $matricula = filter_input(INPUT_POST, 'matricula', FILTER_SANITIZE_STRING);
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $areaId = filter_input(INPUT_POST, 'areaId', FILTER_VALIDATE_INT);

    $nombre = strtoupper($nombre);

    if ($matricula && $nombre && $areaId) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE matricula = :matricula");
        $stmt->execute(['matricula' => $matricula]);
        $usuarioExistente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuarioExistente) {
            echo "<div class='alert alert-danger'>La matrícula ya está registrada. Por favor, elige otra.</div>";
        } else {
            $stmt = $pdo->prepare("INSERT INTO usuarios (matricula, nombre, areaId) VALUES (:matricula, :nombre, :areaId)");
            $stmt->execute(['matricula' => $matricula, 'nombre' => $nombre, 'areaId' => $areaId]);
        }
    }
}

// Obtener las áreas para el formulario
$areas = $pdo->query("SELECT * FROM areas")->fetchAll(PDO::FETCH_ASSOC);

// Parámetros de búsqueda
$criterioBusqueda = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';

// Paginación
$registrosPorPagina = 8;
$paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$inicio = ($paginaActual - 1) * $registrosPorPagina;

// Consulta SQL con filtro de búsqueda
$sql = "SELECT u.matricula, u.nombre, a.nombreArea 
        FROM usuarios u 
        JOIN areas a ON u.areaId = a.id_area 
        WHERE (u.matricula LIKE :criterio OR u.nombre LIKE :criterio)
        LIMIT :inicio, :registrosPorPagina";

$stmt = $pdo->prepare($sql);
$criterioBusquedaParam = '%' . $criterioBusqueda . '%';
$stmt->bindParam(':criterio', $criterioBusquedaParam, PDO::PARAM_STR);
$stmt->bindParam(':inicio', $inicio, PDO::PARAM_INT);
$stmt->bindParam(':registrosPorPagina', $registrosPorPagina, PDO::PARAM_INT);
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener el total de registros que coinciden con el filtro
$stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios u WHERE (u.matricula LIKE :criterio OR u.nombre LIKE :criterio)");
$stmt->bindParam(':criterio', $criterioBusquedaParam, PDO::PARAM_STR);
$stmt->execute();
$totalRegistros = $stmt->fetchColumn();
$totalPaginas = ceil($totalRegistros / $registrosPorPagina);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function confirmarEliminacion(matricula) {
            if (confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
                window.location.href = "?eliminar=" + matricula;
            }
        }
    </script>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Panel de Control - Registro de Usuarios</h1>

    <div class="d-flex justify-content-end mb-3">
        <a href="superadmi.php" class="btn btn-danger">Salir</a>
    </div>

    <h2>Registrar Nuevo Usuario</h2>
    <form method="POST" class="mb-4">
        <div class="mb-3">
            <label for="matricula" class="form-label">Matrícula</label>
            <input type="text" id="matricula" name="matricula" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" id="nombre" name="nombre" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="areaId" class="form-label">Área</label>
            <select id="areaId" name="areaId" class="form-control" required>
                <option value="">Seleccione un área</option>
                <?php foreach ($areas as $area): ?>
                    <option value="<?php echo $area['id_area']; ?>"><?php echo htmlspecialchars($area['nombreArea']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

     
        <button type="submit" name="registrar" class="btn btn-primary">Registrar</button>
    </form>

                <!-- Filtro de busqueda por usuario o matricula-->
 <div class="d-flex justify-content-end mb-3">
    <form class="d-flex" method="GET">
        <input type="text" name="buscar" class="form-control me-2" placeholder="Buscar Usuario" value="<?php echo htmlspecialchars($criterioBusqueda); ?>">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </form>
</div>

    <h2>Usuarios Registrados</h2>
    <table class="table table-striped">
        <thead>
        <tr>
            <th>Matrícula</th>
            <th>Nombre</th>
            <th>Área</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $usuario): ?>
            <tr>
                <td><?php echo htmlspecialchars($usuario['matricula']); ?></td>
                <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                <td><?php echo htmlspecialchars($usuario['nombreArea']); ?></td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="confirmarEliminacion('<?php echo $usuario['matricula']; ?>')">Eliminar</button>
                    <a href="modificarUsuario.php?matricula=<?php echo $usuario['matricula']; ?>" class="btn btn-warning btn-sm">Modificar</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php if ($paginaActual > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?buscar=<?php echo urlencode($criterioBusqueda); ?>&pagina=<?php echo $paginaActual - 1; ?>" aria-label="Anterior">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                <li class="page-item <?php echo $i == $paginaActual ? 'active' : ''; ?>">
                    <a class="page-link" href="?buscar=<?php echo urlencode($criterioBusqueda); ?>&pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($paginaActual < $totalPaginas): ?>
                <li class="page-item">
                    <a class="page-link" href="?buscar=<?php echo urlencode($criterioBusqueda); ?>&pagina=<?php echo $paginaActual + 1; ?>" aria-label="Siguiente">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
