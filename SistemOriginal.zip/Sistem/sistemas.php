<?php
require 'bd.php'; // Conexión a la base de datos

// Obtener todos los usuarios registrados para el combo box
$stmt = $pdo->query("SELECT matricula, nombre FROM usuarios");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener los tickets generados por el área de sistemas
$id_area = 37; // El id_area de la área registrada
$stmt = $pdo->prepare("SELECT t.*, u.nombre AS nombre_usuario FROM tickets t 
    JOIN usuarios u ON t.matricula = u.matricula 
    WHERE t.id_area = :id_area");
$stmt->execute(['id_area' => $id_area]);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Manejar el registro de un nuevo ticket
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $matricula = filter_input(INPUT_POST, 'matricula', FILTER_SANITIZE_STRING);
    $falla = filter_input(INPUT_POST, 'falla', FILTER_SANITIZE_STRING);
    $observaciones = filter_input(INPUT_POST, 'observaciones', FILTER_SANITIZE_STRING);
    $idAdmi = 4; // Asignar el valor de idAdmi

    // Validar los campos obligatorios
    if ($matricula && $falla) {
        try {
            // Insertar el nuevo ticket en la base de datos
            $stmt = $pdo->prepare("INSERT INTO tickets (fecha, falla, observaciones, status, matricula, id_area, idAdmi) 
                VALUES (NOW(), :falla, :observaciones, 'abierto', :matricula, :id_area, :idAdmi)");
            $stmt->execute([
                'falla' => $falla,
                'observaciones' => $observaciones ?: null,
                'matricula' => $matricula,
                'id_area' => $id_area,
                'idAdmi' => $idAdmi
            ]);

            // Redirigir al usuario después de una inserción exitosa
            header('Location: sistemas.php'); // Redirigir al archivo correspondiente
            exit(); 
        } catch (PDOException $e) {
            echo "Error al registrar el ticket: " . $e->getMessage();
        }
    } else {
        echo "Error: Debes completar todos los campos obligatorios.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tickets del Área de sistemas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-red {
            background-color: red;
            color: white;
        }
        .status-open {
            background-color: green;
            color: white;
            padding: 5px 10px; /* Espaciado alrededor del texto */
            border-radius: 5px; /* Bordes redondeados */
            display: inline-block; /* Para que tenga un tamaño adecuado */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Tickets del Área de sistemas</h1>

    <!-- Botón para abrir el modal de nuevo ticket -->
    <button class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#nuevoTicketModal">Registrar Nuevo Ticket</button>

    <!-- Tabla para mostrar los tickets generados -->
    <table class="table table-striped">
        <thead>
        <tr>
            <th>ID Ticket</th>
            <th>Nombre Usuario</th>
            <th>Fecha</th>
            <th>Falla</th>
            <th>Observaciones</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $ticket): ?>
            <tr>
                <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <span class="status-open">Abierto</span>
                    <?php else: ?>
                        <?php echo htmlspecialchars($ticket['status']); ?>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Botón para regresar a inicio.html -->
    <div class="text-center">
        <a href="inicio.html" class="btn btn-red">Salir</a>
    </div>
</div>

<!-- Modal para registrar un nuevo ticket -->
<div class="modal fade" id="nuevoTicketModal" tabindex="-1" aria-labelledby="nuevoTicketModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="nuevoTicketModalLabel">Registrar Nuevo Ticket</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="matricula" class="form-label">Nombre Usuario</label>
                        <select name="matricula" id="matricula" class="form-control" required>
                            <option value="">Seleccione un usuario</option>
                            <?php foreach ($usuarios as $usuario): ?>
                                <option value="<?php echo htmlspecialchars($usuario['matricula']); ?>">
                                    <?php echo htmlspecialchars($usuario['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="falla" class="form-label">Falla</label>
                        <select name="falla" id="falla" class="form-control" required>
                            <option value="Servicio de internet">Servicio de internet</option>
                            <option value="Equipo de computo">Equipo de cómputo</option>
                            <option value="Telefonía">Telefonía</option>
                            <option value="Impresión">Impresión</option>
                            <option value="Mantenimiento preventivo">Mantenimiento preventivo</option>
                            <option value="Reubicación de equipos">Reubicación de equipos</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="observaciones" class="form-label">Observaciones</label>
                        <textarea name="observaciones" id="observaciones" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary">Guardar Ticket</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>