<?php
// Conexión a la base de datos
require 'bd.php'; // Conexión a la base de datos

// Si el formulario es enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreArea = $_POST['nombreArea'];
    $claveIngresada = $_POST['clave'];

    // Consulta para verificar si la clave coincide con el área seleccionada
    $stmt = $pdo->prepare("SELECT clave FROM areas WHERE nombreArea = :nombreArea");
    $stmt->bindParam(':nombreArea', $nombreArea);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result && $result['clave'] === $claveIngresada) {
        // Redirigir a la página correspondiente si la clave es correcta
        header("Location: $nombreArea.php");
        exit();
    } else {
        // Mensaje de error si la clave es incorrecta
        $error = "Clave incorrecta para el área seleccionada.";
    }
}

// Consulta para obtener todas las áreas
$stmt = $pdo->query("SELECT nombreArea FROM areas");
$areas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Áreas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Definir el color azul marino personalizado */
        .bg-navy {
            background-color: #001f3f !important;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

    <!-- Encabezado con color azul marino -->
    <header class="bg-navy text-white py-4">
        <div class="container text-center">
            <h1 class="display-4">Sistema de Tickets</h1>
            <p class="lead">Registro de Áreas</p>
        </div>
    </header>

    <!-- Contenido principal -->
    <main class="flex-grow-1 d-flex justify-content-center align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title text-center">Seleccione su Área</h2>

                            <?php if (isset($error)) { ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo $error; ?>
                                </div>
                            <?php } ?>

                            <form method="POST" action="registroArea.php">
                                <div class="mb-3">
                                    <label for="nombreArea" class="form-label">Área:</label>
                                    <select name="nombreArea" id="nombreArea" class="form-select" required>
                                        <?php foreach ($areas as $area) { ?>
                                            <option value="<?php echo htmlspecialchars($area['nombreArea']); ?>">
                                                <?php echo htmlspecialchars($area['nombreArea']); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="clave" class="form-label">Clave:</label>
                                    <input type="password" name="clave" id="clave" class="form-control" required>
                                </div>

                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Ingresar</button>
                                    <button type="button" class="btn btn-secondary" onclick="window.location.href='inicio.html'">Regresar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Pie de página con color azul marino -->
    <footer class="bg-navy text-white text-center py-3">
        <div class="container">
            <p class="mb-0">&copy; 2024 Sistema de Tickets. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Scripts de Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
