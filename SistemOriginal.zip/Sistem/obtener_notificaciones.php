<?php
require 'bd.php';

// Contar notificaciones pendientes
$stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM notificaciones WHERE estado = 'Pendiente'");
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Devolver como JSON
echo json_encode(['numeroNotificaciones' => $result['total']]);
?>
