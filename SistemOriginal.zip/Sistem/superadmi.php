<?php
require 'bd.php'; // Conexión a la base de datos

// Definir cuántos tickets mostrar por página
$tickets_por_pagina = 8;

// Obtener el número total de tickets
$total_tickets = $pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn();

// Calcular el número total de páginas
$total_paginas = ceil($total_tickets / $tickets_por_pagina);

// Obtener el número de página actual desde la URL, o establecerlo a 1
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$pagina_actual = max($pagina_actual, 1); // Asegurarse de que la página sea al menos 1
$pagina_actual = min($pagina_actual, $total_paginas); // Asegurarse de que no exceda el total de páginas

// Calcular el índice de inicio para la consulta
$inicio = ($pagina_actual - 1) * $tickets_por_pagina;

// Manejar la búsqueda de tickets
$search_query = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])) {
    $search_query = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_STRING);
    // Preparar la consulta SQL con búsqueda
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        WHERE t.id_ticket LIKE :search 
        OR u.nombre LIKE :search 
        OR a.nombreArea LIKE :search
        ORDER BY t.fecha DESC  -- Ordenar por fecha, los más nuevos primero
        LIMIT :inicio, :tickets_por_pagina
    ");
    $stmt->bindValue('search', '%' . $search_query . '%', PDO::PARAM_STR);
    $stmt->bindValue('inicio', $inicio, PDO::PARAM_INT);
    $stmt->bindValue('tickets_por_pagina', $tickets_por_pagina, PDO::PARAM_INT);
    $stmt->execute();
} else {
    // Obtener tickets con paginación si no hay búsqueda
    $stmt = $pdo->prepare("
        SELECT t.*, a.nombreArea, u.nombre AS nombre_usuario 
        FROM tickets t 
        JOIN areas a ON t.id_area = a.id_area 
        JOIN usuarios u ON t.matricula = u.matricula
        ORDER BY t.fecha DESC  -- Ordenar por fecha, los más nuevos primero
        LIMIT :inicio, :tickets_por_pagina
    ");
    $stmt->bindValue('inicio', $inicio, PDO::PARAM_INT);
    $stmt->bindValue('tickets_por_pagina', $tickets_por_pagina, PDO::PARAM_INT);
    $stmt->execute();
}
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Manejar la solicitud de cierre de ticket
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_ticket'])) {
    $id_ticket = filter_input(INPUT_POST, 'id_ticket', FILTER_SANITIZE_NUMBER_INT);
    try {
        // Actualizar el estado del ticket a cerrado y establecer la fecha de cierre
        $stmt = $pdo->prepare("UPDATE tickets SET status = 'cerrado', fechacerrado = NOW() WHERE id_ticket = :id_ticket");
        $stmt->execute(['id_ticket' => $id_ticket]);
        
        // Redirigir después de cerrar el ticket
        header('Location: superadmi.php');
        exit();
    } catch (PDOException $e) {
        echo "Error al cerrar el ticket: " . $e->getMessage();
    }
}

// Manejar la solicitud de eliminación de ticket
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id_ticket'])) {
    $delete_id_ticket = filter_input(INPUT_POST, 'delete_id_ticket', FILTER_SANITIZE_NUMBER_INT);
    try {
        // Eliminar el ticket de la base de datos
        $stmt = $pdo->prepare("DELETE FROM tickets WHERE id_ticket = :delete_id_ticket");
        $stmt->execute(['delete_id_ticket' => $delete_id_ticket]);

        // Redirigir después de eliminar el ticket
        header('Location: superadmi.php');
        exit();
    } catch (PDOException $e) {
        echo "Error al eliminar el ticket: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>superadmi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-red {
            background-color: red;
            color: white;
        }
        .status-open {
            background-color: green;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Super Administrador</h1>

    <!-- Formulario de Búsqueda -->
    <form method="POST" class="mb-4">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Buscar por ID, Usuario o Área" value="<?php echo htmlspecialchars($search_query); ?>">
            <button class="btn btn-primary" type="submit">Buscar</button>
        </div>
    </form>

    <!-- Botones para ir a diferentes paneles -->
    <div class="text-center mb-4">
        <a href="panelUsuarios.php" class="btn btn-info">Ir a Panel Usuarios</a>
        <a href="panel.php" class="btn btn-info">Ir a Panel Areas</a>
        <a href="panelAdmi.php" class="btn btn-info">Ir a Panel Administradores</a>
        <a href="exportar_pdf.php" class="btn btn-success" target="_blank">Exportar a PDF</a>

    </div>

    <table class="table table-striped">
        <thead>
        <tr>
            <th>ID Ticket</th>
            <th>Nombre Usuario</th>
            <th>Área Generadora</th>
            <th>Fecha</th>
            <th>Falla</th>
            <th>Observaciones</th>
            <th>Status</th>
            <th>Fecha de Cierre</th>
            <th>Modificar</th>
            <th>Eliminar</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $ticket): ?>
            <tr>
                <td><?php echo htmlspecialchars($ticket['id_ticket']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombre_usuario']); ?></td>
                <td><?php echo htmlspecialchars($ticket['nombreArea']); ?></td>
                <td><?php echo htmlspecialchars($ticket['fecha']); ?></td>
                <td><?php echo htmlspecialchars($ticket['falla']); ?></td>
                <td><?php echo htmlspecialchars($ticket['observaciones']); ?></td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <span class="status-open">Abierto</span>
                    <?php else: ?>
                        <?php echo htmlspecialchars($ticket['status']); ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'cerrado'): ?>
                        <?php echo htmlspecialchars($ticket['fechaCerrado']); ?>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($ticket['status'] === 'abierto'): ?>
                        <!-- Botón para abrir el modal de modificación -->
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modificarModal<?php echo $ticket['id_ticket']; ?>">Modificar</button>
                    <?php endif; ?>
                </td>
                <td>
                    <!-- Botón para abrir el modal de eliminación -->
                    <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarModal<?php echo $ticket['id_ticket']; ?>">Eliminar</button>
                </td>
            </tr>

            <!-- Modal para cerrar el ticket -->
            <div class="modal fade" id="modificarModal<?php echo $ticket['id_ticket']; ?>" tabindex="-1" aria-labelledby="modificarModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modificarModalLabel">Cerrar Ticket ID: <?php echo $ticket['id_ticket']; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <p>¿Estás seguro de que deseas cerrar este ticket?</p>
                                <input type="hidden" name="id_ticket" value="<?php echo htmlspecialchars($ticket['id_ticket']); ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-primary">Cerrar Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Modal para eliminar el ticket -->
            <div class="modal fade" id="eliminarModal<?php echo $ticket['id_ticket']; ?>" tabindex="-1" aria-labelledby="eliminarModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="eliminarModalLabel">Eliminar Ticket ID: <?php echo $ticket['id_ticket']; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST">
                            <div class="modal-body">
                                <p>¿Estás seguro de que deseas eliminar este ticket?</p>
                                <input type="hidden" name="delete_id_ticket" value="<?php echo htmlspecialchars($ticket['id_ticket']); ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-danger">Eliminar Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Botones de navegación -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php if ($pagina_actual > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual - 1; ?>" aria-label="Anterior">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?php echo ($i === $pagina_actual) ? 'active' : ''; ?>">
                    <a class="page-link" href="?pagina=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($pagina_actual < $total_paginas): ?>
                <li class="page-item">
                    <a class="page-link" href="?pagina=<?php echo $pagina_actual + 1; ?>" aria-label="Siguiente">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="text-center">
        <a href="inicio.html" class="btn btn-red">Salir</a>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>