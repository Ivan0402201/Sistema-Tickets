<?php
require 'bd.php'; // Incluir la conexión a la base de datos

// Obtener la matrícula del usuario que se va a modificar
$matricula = filter_input(INPUT_GET, 'matricula', FILTER_SANITIZE_STRING);

if (!$matricula) {
    die('Matrícula no válida');
}

// Obtener el usuario actual desde la base de datos
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE matricula = :matricula");
$stmt->execute(['matricula' => $matricula]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    die('Usuario no encontrado');
}

// Obtener las áreas disponibles
$stmt = $pdo->query("SELECT id_area, nombreArea FROM areas");
$areas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Manejar la modificación de un usuario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nuevoNombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $nuevoAreaId = filter_input(INPUT_POST, 'areaId', FILTER_VALIDATE_INT);

    if ($nuevoNombre && $nuevoAreaId) {
        // Actualizar el nombre y área del usuario
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = :nombre, areaId = :areaId WHERE matricula = :matricula");
        $stmt->execute([
            'nombre' => $nuevoNombre,
            'areaId' => $nuevoAreaId,
            'matricula' => $matricula
        ]);

        // Redirigir al panel de usuarios
        header("Location: panelUsuarios.php");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Modificar Usuario</h1>

    <!-- Formulario para modificar el usuario -->
    <form method="POST">
        <div class="mb-3">
            <label for="matricula" class="form-label">Matrícula</label>
            <input type="text" id="matricula" name="matricula" class="form-control" value="<?php echo htmlspecialchars($usuario['matricula']); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="areaId" class="form-label">Área</label>
            <select id="areaId" name="areaId" class="form-control" required>
                <?php foreach ($areas as $area): ?>
                    <option value="<?php echo $area['id_area']; ?>" <?php echo $area['id_area'] == $usuario['areaId'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($area['nombreArea']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <a href="panelUsuarios.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>


<!-- Script de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>