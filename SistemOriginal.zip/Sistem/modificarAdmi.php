<?php
require 'bd.php'; // Incluir la conexión a la base de datos

// Obtener el id del administrador que se va a modificar
$idAdmi = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$idAdmi) {
    die('ID de administrador no válido');
}

// Obtener el administrador actual desde la base de datos
$stmt = $pdo->prepare("SELECT * FROM admis WHERE idAdmi = :idAdmi");
$stmt->execute(['idAdmi' => $idAdmi]);
$admi = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admi) {
    die('Administrador no encontrado');
}

// Manejar la modificación de un administrador
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nuevoNombreAdmi = filter_input(INPUT_POST, 'NombreAdmi', FILTER_SANITIZE_STRING);
    $correoAdmi = filter_input(INPUT_POST, 'CorreoAdmi', FILTER_SANITIZE_EMAIL);
    $nuevaClave = $_POST['nueva_clave']; // Si se ha proporcionado una nueva clave

    if ($nuevoNombreAdmi && $correoAdmi) {
        // Nombre de archivo anterior
        $nombreArchivoAnterior = strtolower(str_replace(' ', '_', $admi['NombreAdmi'])) . '.php';
        // Nombre de archivo nuevo
        $nombreArchivoNuevo = strtolower(str_replace(' ', '_', $nuevoNombreAdmi)) . '.php';

        // Si el nombre ha cambiado, renombrar el archivo
        if ($nuevoNombreAdmi !== $admi['NombreAdmi']) {
            // Comprobar si el archivo anterior existe
            if (file_exists($nombreArchivoAnterior)) {
                // Obtener el contenido del archivo anterior
                $contenidoAnterior = file_get_contents($nombreArchivoAnterior);

                // Renombrar el archivo con el nuevo nombre
                if (!rename($nombreArchivoAnterior, $nombreArchivoNuevo)) {
                    die('Error al renombrar el archivo');
                }

                // Escribir el contenido en el archivo renombrado
                file_put_contents($nombreArchivoNuevo, $contenidoAnterior);
            } else {
                // Si el archivo no existe, crear un nuevo archivo vacío
                $contenidoAnterior = <<<EOD
                <?php
                // Este archivo fue generado automáticamente
                ?>

                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Administrador - {$nuevoNombreAdmi}</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                </head>
                <body>
                <div class="container mt-5">
                    <h1 class="text-center">Página de Administrador - {$nuevoNombreAdmi}</h1>
                    <p>Esta página está vacía por ahora.</p>
                </div>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
                </body>
                </html>
                EOD;

                // Crear un archivo con el contenido por defecto
                file_put_contents($nombreArchivoNuevo, $contenidoAnterior);
            }
        }

        // Si se ha proporcionado una nueva clave, actualizarla, de lo contrario, dejar la clave actual
        if (!empty($nuevaClave)) {
            // No encriptar la nueva clave, solo actualizarla directamente
            $stmt = $pdo->prepare("UPDATE admis SET NombreAdmi = :NombreAdmi, CorreoAdmi = :CorreoAdmi, clave = :clave WHERE idAdmi = :idAdmi");
            $stmt->execute(['NombreAdmi' => $nuevoNombreAdmi, 'CorreoAdmi' => $correoAdmi, 'clave' => $nuevaClave, 'idAdmi' => $idAdmi]);
        } else {
            $stmt = $pdo->prepare("UPDATE admis SET NombreAdmi = :NombreAdmi, CorreoAdmi = :CorreoAdmi WHERE idAdmi = :idAdmi");
            $stmt->execute(['NombreAdmi' => $nuevoNombreAdmi, 'CorreoAdmi' => $correoAdmi, 'idAdmi' => $idAdmi]);
        }

        // Redirigir al panel
        header("Location: panelAdmi.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Modificar Administrador</h1>

    <!-- Formulario para modificar el administrador -->
    <form method="POST">
        <div class="mb-3">
            <label for="NombreAdmi" class="form-label">Nombre</label>
            <input type="text" id="NombreAdmi" name="NombreAdmi" class="form-control" value="<?php echo htmlspecialchars($admi['NombreAdmi']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="CorreoAdmi" class="form-label">Correo</label>
            <input type="email" id="CorreoAdmi" name="CorreoAdmi" class="form-control" value="<?php echo htmlspecialchars($admi['CorreoAdmi']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="nueva_clave" class="form-label">Nueva Contraseña</label>
            <input type="password" id="nueva_clave" name="nueva_clave" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        <a href="panelAdmi.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<!-- Script de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
