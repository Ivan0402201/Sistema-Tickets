<?php
$servername = 'localhost'; // Nombre del servidor
$dbname = 'Ivan'; // Nombre de la base de datos 
$username = 'Desarrollo'; // Nombre de usuario (con doble barra invertida para autenticación de Windows)
$password = '040201'; // Si usas autenticación de Windows, probablemente no necesitarás contraseña

try {
    // Conexión a SQL Server usando el controlador sqlsrv
    $pdo = new PDO("mysql: host=$servername; dbname=$dbname", $username, $password);
    
    // Establecer el modo de error de PDO a excepción
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "";
} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}
?>

